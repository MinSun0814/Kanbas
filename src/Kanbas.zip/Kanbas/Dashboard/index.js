import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import db from '../Database';
import './index.css';

function Dashboard() {
  const [courses, setCourses] = useState(db.courses);
  const [course, setCourse] = useState({ _id: '', name: '', number: '', startDate: '', endDate: '', image: '' });

  const addNewCourse = () => {
    const newCourse = {
      ...course,
      _id: new Date().getTime().toString(),
      image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=3570&q=80",
    };
    setCourses([...courses, newCourse]);
  };

  const updateCourse = () => {
    const updatedCourses = courses.map(c => (c._id === course._id ? course : c));
    setCourses(updatedCourses);
  };

  const deleteCourse = (id) => {
    const newCourses = courses.filter(course => course._id !== id);
    setCourses(newCourses);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setCourse({ ...course, [name]: value });
  };

  return (
      <div>
        <div>
          <input type="text" name="name" placeholder="Name" value={course.name} onChange={handleInputChange} />
          <input type="text" name="number" placeholder="Number" value={course.number} onChange={handleInputChange} />
          <input type="date" name="startDate" placeholder="Start Date" value={course.startDate} onChange={handleInputChange} />
          <input type="date" name="endDate" placeholder="End Date" value={course.endDate} onChange={handleInputChange} />
          <button onClick={addNewCourse}>Add Course</button>
          <button onClick={updateCourse}>Update Course</button>
        </div>
        <div className="row row-cols-1 row-cols-md-3 row-cols-sm-2 row-cols-xl-4 custom-gap">
          {courses.map((c) => (
              <div key={c._id} className="col mb-4">
                <div className="card fixed-width-card">
                  <img src={c.image || "https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=3570&q=80"} className="card-img-top" alt={c.name} />
                  <div className="card-body">
                    <h5 className="card-title">{c.name}</h5>
                    <h6 className="card-title">{c.semester}</h6>
                    <p className="card-text">Number: {c.number}</p>
                    <p className="card-text">Start Date: {c.startDate}</p>
                    <p className="card-text">End Date: {c.endDate}</p>
                    <p className="card-text">
                      <Link className = "redLink" to={`/Kanbas/Courses/${c._id}`}>This is the link to the course.</Link>
                    </p>
                    <button onClick={() => deleteCourse(c._id)}>Delete</button>
                    <button onClick={() => setCourse(c)}>Edit</button>
                  </div>
                </div>
              </div>
          ))}
        </div>
      </div>
  );
}

export default Dashboard;
