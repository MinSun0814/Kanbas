import ModuleList from "./ModuleList";
function Modules() {
  return (
      <div>
        <h2>Modules</h2>
        <ModuleList />
      </div>
  );
}
export default Modules;